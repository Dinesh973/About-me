import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Briefcase, GraduationCap, Mail, MapPin, Github, Linkedin, Twitter, Award, FileText, Code } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="font-bold text-xl">
            Your Name
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="#about" className="text-sm font-medium hover:underline underline-offset-4">
              About
            </Link>
            <Link href="#experience" className="text-sm font-medium hover:underline underline-offset-4">
              Experience
            </Link>
            <Link href="#education" className="text-sm font-medium hover:underline underline-offset-4">
              Education
            </Link>
            <Link href="#skills" className="text-sm font-medium hover:underline underline-offset-4">
              Skills
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:underline underline-offset-4">
              Contact
            </Link>
          </nav>
          <Button asChild size="sm" className="hidden md:flex">
            <Link href="#contact">Get in touch</Link>
          </Button>
          <Button variant="outline" size="icon" className="md:hidden">
            <span className="sr-only">Toggle menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-4 w-4"
            >
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        <section id="about" className="container py-12 md:py-24 lg:py-32">
          <div className="grid gap-10 md:grid-cols-2 md:gap-16">
            <div>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Your Name</h1>
              <p className="mt-2 text-xl text-muted-foreground">Professional Title</p>
              <div className="mt-4 flex items-center gap-2 text-muted-foreground">
                <MapPin className="h-4 w-4" />
                <span>Location</span>
              </div>
              <p className="mt-6">
                This is where you can add your professional summary from LinkedIn. Highlight your expertise, experience,
                and what makes you unique in your field. A compelling summary helps visitors quickly understand your
                professional background and value proposition.
              </p>
              <div className="mt-8 flex gap-4">
                <Button asChild variant="outline" size="icon">
                  <Link href="https://linkedin.com/in/yourprofile" target="_blank">
                    <Linkedin className="h-4 w-4" />
                    <span className="sr-only">LinkedIn</span>
                  </Link>
                </Button>
                <Button asChild variant="outline" size="icon">
                  <Link href="https://github.com/yourusername" target="_blank">
                    <Github className="h-4 w-4" />
                    <span className="sr-only">GitHub</span>
                  </Link>
                </Button>
                <Button asChild variant="outline" size="icon">
                  <Link href="https://twitter.com/yourusername" target="_blank">
                    <Twitter className="h-4 w-4" />
                    <span className="sr-only">Twitter</span>
                  </Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/resume.pdf" target="_blank">
                    <FileText className="mr-2 h-4 w-4" />
                    Download Resume
                  </Link>
                </Button>
              </div>
            </div>
            <div className="flex justify-center md:justify-end">
              <Avatar className="h-64 w-64">
                <AvatarImage src="/placeholder.svg?height=256&width=256" alt="Your Name" />
                <AvatarFallback>YN</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </section>

        <section id="experience" className="bg-muted py-12 md:py-24 lg:py-32">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tighter mb-12 flex items-center gap-2">
              <Briefcase className="h-8 w-8" />
              Experience
            </h2>
            <div className="grid gap-8">
              {/* Experience Item 1 */}
              <Card>
                <CardContent className="p-6">
                  <div className="grid gap-4 md:grid-cols-[1fr_3fr]">
                    <div className="flex flex-col items-start">
                      <Avatar className="h-16 w-16 rounded-md">
                        <AvatarImage src="/placeholder.svg?height=64&width=64" alt="Company Logo" />
                        <AvatarFallback className="rounded-md">CO</AvatarFallback>
                      </Avatar>
                      <div className="mt-4 text-sm text-muted-foreground">Jan 2020 - Present</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">Job Title</h3>
                      <p className="text-muted-foreground">Company Name</p>
                      <p className="mt-4">
                        Describe your responsibilities, achievements, and the impact you made in this role. Include
                        specific projects, initiatives, or results that showcase your skills and expertise.
                      </p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Badge variant="secondary">Skill 1</Badge>
                        <Badge variant="secondary">Skill 2</Badge>
                        <Badge variant="secondary">Skill 3</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Experience Item 2 */}
              <Card>
                <CardContent className="p-6">
                  <div className="grid gap-4 md:grid-cols-[1fr_3fr]">
                    <div className="flex flex-col items-start">
                      <Avatar className="h-16 w-16 rounded-md">
                        <AvatarImage src="/placeholder.svg?height=64&width=64" alt="Company Logo" />
                        <AvatarFallback className="rounded-md">CO</AvatarFallback>
                      </Avatar>
                      <div className="mt-4 text-sm text-muted-foreground">Jan 2018 - Dec 2019</div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">Previous Job Title</h3>
                      <p className="text-muted-foreground">Previous Company Name</p>
                      <p className="mt-4">
                        Describe your responsibilities, achievements, and the impact you made in this role. Include
                        specific projects, initiatives, or results that showcase your skills and expertise.
                      </p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Badge variant="secondary">Skill 1</Badge>
                        <Badge variant="secondary">Skill 2</Badge>
                        <Badge variant="secondary">Skill 3</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="education" className="py-12 md:py-24 lg:py-32">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tighter mb-12 flex items-center gap-2">
              <GraduationCap className="h-8 w-8" />
              Education
            </h2>
            <div className="grid gap-8 md:grid-cols-2">
              {/* Education Item 1 */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    <Avatar className="h-16 w-16 rounded-md">
                      <AvatarImage src="/placeholder.svg?height=64&width=64" alt="University Logo" />
                      <AvatarFallback className="rounded-md">UN</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-xl font-bold">Degree Name</h3>
                      <p className="text-muted-foreground">University Name</p>
                      <p className="mt-2 text-sm text-muted-foreground">2014 - 2018</p>
                      <p className="mt-4">
                        Add details about your education, including relevant coursework, projects, achievements, or
                        activities.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Education Item 2 */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    <Avatar className="h-16 w-16 rounded-md">
                      <AvatarImage src="/placeholder.svg?height=64&width=64" alt="University Logo" />
                      <AvatarFallback className="rounded-md">UN</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-xl font-bold">Another Degree or Certification</h3>
                      <p className="text-muted-foreground">Institution Name</p>
                      <p className="mt-2 text-sm text-muted-foreground">2020</p>
                      <p className="mt-4">
                        Add details about additional education or certifications that are relevant to your professional
                        profile.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="skills" className="bg-muted py-12 md:py-24 lg:py-32">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tighter mb-12 flex items-center gap-2">
              <Code className="h-8 w-8" />
              Skills & Expertise
            </h2>
            <Tabs defaultValue="technical" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:w-[400px]">
                <TabsTrigger value="technical">Technical Skills</TabsTrigger>
                <TabsTrigger value="soft">Soft Skills</TabsTrigger>
              </TabsList>
              <TabsContent value="technical" className="mt-6">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold mb-4">Programming Languages</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge>JavaScript</Badge>
                        <Badge>TypeScript</Badge>
                        <Badge>Python</Badge>
                        <Badge>Java</Badge>
                        <Badge>C#</Badge>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold mb-4">Frameworks & Libraries</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge>React</Badge>
                        <Badge>Next.js</Badge>
                        <Badge>Node.js</Badge>
                        <Badge>Express</Badge>
                        <Badge>Django</Badge>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold mb-4">Tools & Technologies</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge>Git</Badge>
                        <Badge>Docker</Badge>
                        <Badge>AWS</Badge>
                        <Badge>CI/CD</Badge>
                        <Badge>Agile</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="soft" className="mt-6">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold mb-4">Communication</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge>Public Speaking</Badge>
                        <Badge>Technical Writing</Badge>
                        <Badge>Presentation</Badge>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold mb-4">Leadership</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge>Team Management</Badge>
                        <Badge>Mentoring</Badge>
                        <Badge>Strategic Planning</Badge>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="font-bold mb-4">Other Skills</h3>
                      <div className="flex flex-wrap gap-2">
                        <Badge>Problem Solving</Badge>
                        <Badge>Critical Thinking</Badge>
                        <Badge>Time Management</Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        <section id="certifications" className="py-12 md:py-24 lg:py-32">
          <div className="container">
            <h2 className="text-3xl font-bold tracking-tighter mb-12 flex items-center gap-2">
              <Award className="h-8 w-8" />
              Certifications & Awards
            </h2>
            <div className="grid gap-8 md:grid-cols-3">
              {/* Certification Item 1 */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    <Avatar className="h-12 w-12 rounded-md">
                      <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Certification Logo" />
                      <AvatarFallback className="rounded-md">CE</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-bold">Certification Name</h3>
                      <p className="text-muted-foreground">Issuing Organization</p>
                      <p className="mt-2 text-sm text-muted-foreground">Issued: Jan 2022</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Certification Item 2 */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    <Avatar className="h-12 w-12 rounded-md">
                      <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Certification Logo" />
                      <AvatarFallback className="rounded-md">CE</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-bold">Another Certification</h3>
                      <p className="text-muted-foreground">Issuing Organization</p>
                      <p className="mt-2 text-sm text-muted-foreground">Issued: Mar 2021</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Award Item */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4">
                    <Avatar className="h-12 w-12 rounded-md">
                      <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Award Logo" />
                      <AvatarFallback className="rounded-md">AW</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="text-lg font-bold">Award Name</h3>
                      <p className="text-muted-foreground">Awarding Organization</p>
                      <p className="mt-2 text-sm text-muted-foreground">Received: Jun 2020</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="contact" className="bg-muted py-12 md:py-24 lg:py-32">
          <div className="container">
            <div className="grid gap-10 md:grid-cols-2 md:gap-16">
              <div>
                <h2 className="text-3xl font-bold tracking-tighter mb-6">Get in Touch</h2>
                <p className="mb-8">
                  I'm always open to discussing new projects, opportunities, or partnerships. Feel free to reach out
                  using the contact form or through my social media profiles.
                </p>
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-muted-foreground" />
                    <span>your.email@example.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <span>Your Location</span>
                  </div>
                </div>
                <div className="mt-8 flex gap-4">
                  <Button asChild variant="outline" size="icon">
                    <Link href="https://linkedin.com/in/yourprofile" target="_blank">
                      <Linkedin className="h-4 w-4" />
                      <span className="sr-only">LinkedIn</span>
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="icon">
                    <Link href="https://github.com/yourusername" target="_blank">
                      <Github className="h-4 w-4" />
                      <span className="sr-only">GitHub</span>
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="icon">
                    <Link href="https://twitter.com/yourusername" target="_blank">
                      <Twitter className="h-4 w-4" />
                      <span className="sr-only">Twitter</span>
                    </Link>
                  </Button>
                </div>
              </div>
              <div>
                <form className="grid gap-6">
                  <div className="grid gap-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Name
                    </label>
                    <input
                      id="name"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Your name"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="email" className="text-sm font-medium">
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Your email"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Message
                    </label>
                    <textarea
                      id="message"
                      className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Your message"
                    />
                  </div>
                  <Button type="submit">Send Message</Button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-6 md:py-8">
        <div className="container flex flex-col items-center justify-center gap-4 md:flex-row md:justify-between">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} Your Name. All rights reserved.
          </p>
          <nav className="flex gap-4 sm:gap-6">
            <Link href="#about" className="text-sm font-medium hover:underline underline-offset-4">
              About
            </Link>
            <Link href="#experience" className="text-sm font-medium hover:underline underline-offset-4">
              Experience
            </Link>
            <Link href="#education" className="text-sm font-medium hover:underline underline-offset-4">
              Education
            </Link>
            <Link href="#skills" className="text-sm font-medium hover:underline underline-offset-4">
              Skills
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:underline underline-offset-4">
              Contact
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

